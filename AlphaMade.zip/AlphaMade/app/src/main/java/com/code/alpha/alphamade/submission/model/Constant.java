package com.code.alpha.alphamade.submission.model;

public class Constant {
    public static final String type = "type";
    public static final String movie = "movie";
    public static final String tv = "tv";
    public static final String drawable = "drawable";
    public static final String tvShowString = "TV SHOW";
    public static final String discover = "discover";
}
