package com.code.alpha.alphamade.submission.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Movies {
    @SerializedName("movies")
    public List<Movie> movies;
}
